#include <bits/stdc++.h>
using namespace std;

#define MAX_SIZE 100
vector<int> graph[MAX_SIZE];

bool isClique(set<int> nodes){
    bool flag = true;
    for (int x : nodes){
        int che = 0;

        for (int child : graph[x]){
            if (nodes.find(child) != nodes.end())
                che++;
        }

        flag &= (che == (nodes.size() - 1));
    }

    return (flag);
}

int main(){
    int v, e;
    cout<< "Enter the no of vertex : ";
    cin>>v;
    cout<<"Enter the no of edges : ";
    cin>>e;
    cout<<"Enter all edges : "<<endl;

    for (int i = 0; i < e; i++){
        int src, dest;
        cin>>src>>dest;
        graph[src].push_back(dest);
        graph[dest].push_back(src);
    }

    int ans = 0;
    set<int> nodes;
    for (int i = 0; i < (1 << v); i++)
    {
        set<int> curr;
        for (int j = 0; j < v; j++)
        {
            if ((1 << j) & i)
            {
                curr.insert(j + 1);
            }
        }
        if (isClique(curr))
        {
            if (ans < (int)curr.size())
            {
                ans = curr.size();
                nodes = curr;
            }
        }
    }
   
    cout << "Maximum  Clique for given graph : "<<ans<<endl;
    for (int x : nodes)
        cout << x << " " ;
        
    return 0;
}
