#include<bits/stdc++.h>
using namespace std;

//display matrix after performing some operation.
void display(vector<vector<bool>> &graph) {
    int v = graph.size();
    for(int i=0; i<v; i++) {
        for(int j=0; j<v; j++) 
            cout << graph[i][j] << " ";
        cout << endl;
    }
    cout<<endl;
} 

//OR operator to find union.
void findUnion(vector<vector<bool>> &g1, vector<vector<bool>> &g2) {
    int n = max(g1.size(), g2.size());
    vector<vector<bool>> result(n, vector<bool> (n));
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++)
            result[i][j] = (g1[i][j] | g2[i][j]);
    }
    display(result);
}

//AND operator to find intersection.
void findIntersection(vector<vector<bool>> &g1, vector<vector<bool>> &g2) {
    int n = min(g1.size(), g2.size());
    vector<vector<bool>> result(n, vector<bool> (n));
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++)
            result[i][j] = (g1[i][j] & g2[i][j]);
    }
    display(result);
}

//NOT operator to find compliment.
void findComplement(vector<vector<bool>> &g) {
    int n = g.size();
    vector<vector<bool>> result(n, vector<bool> (n));
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++) 
            result[i][j] = !g[i][j];
    }
    display(result);
}

void findDifference(vector<vector<bool>> &g1, vector<vector<bool>> &g2) {
    int n = g1.size();
    vector<vector<bool>> result(n, vector<bool> (n));
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++)
            result[i][j] = (g1[i][j]==1 && g2[i][j]==0);
    }
    display(result);
}

void findSum(vector<vector<bool>> &g1, vector<vector<bool>> &g2) {
    int n = max(g1.size(), g2.size());
    vector<vector<bool>> result(n, vector<bool> (n));
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++)
            result[i][j] = (g1[i][j]==1 ^ g2[i][j]==0);
    }
    display(result);
}


void addEdge(vector<vector<bool>> &graph, int vertex1, int vertex2) {
    graph[vertex1][vertex2] = 1;
    graph[vertex2][vertex1] = 1;
}

int main()
{   
    int v1, v2, e1, e2;
    int vertex1, vertex2;

    //taking vertex & edges for first graph.
    cout<<"--------------- GRAPH 1 ---------------\n";
    cout << "Vertex : ";
    cin >> v1;
    cout << "Edges : ";
    cin >> e1;

    vector<vector<bool>>first(v1, vector<bool>(v1, 0));
    cout << "Enter all edges : \n";
    for(int i=0; i<e1; i++) {
        cin >> vertex1 >> vertex2;
        addEdge(first, vertex1, vertex2);
    }

    cout << "\nAdjancy Matrix for Graph 1 : \n";
    display(first);

    //taking vertex & edges for second graph.
    cout<<"--------------- GRAPH 2 ---------------\n";
    cout << "Vertex : ";
    cin >> v2;
    cout << "Edges : ";
    cin >> e2;

    vector<vector<bool>>second(v2, vector<bool>(v2, 0));
    cout << "Enter all edges : \n";
    for(int i=0; i<e2; i++) {
        cin >> vertex1 >> vertex2;
        addEdge(second, vertex1, vertex2);
    }

    cout << "\nAdjancy Matrix for Graph 2 : \n";
    display(second);

    cout<<"<<<<<<<<<<<<<<< MENU >>>>>>>>>>>>>>>"<<endl;
    cout << "\n1.Union\n2.Intersection\n3.Compliment\n4.Ringsum\n5.Difference\n6.Exit\n" << endl;
    int choice;
    
    do {
        cout << "Enter your choice : ";
        cin >> choice;
        
        switch(choice) {
            case 1:
                findUnion(first, second);
                break;
            case 2:
                findIntersection(first, second);
                break;
            case 3:
                findComplement(first);
                findComplement(second);
                break;
            case 4:
                findSum(first, second);
                break;
            case 5:
                findDifference(first, second);
                break;
            case 6:
                exit(1);
            default:
                cout << "Enter valid choice";
                break;
            }
          
        } while(choice != 6);
    return 0;
}