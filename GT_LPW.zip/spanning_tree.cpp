#include<bits/stdc++.h>
#include<vector>
using namespace std;

//to generate vector with specific size.
//vector with size 4 -> (1,2,3,4)
vector<int> set_of_vertex(int n){

    vector<int> arr;
    for(int i=1 ; i<=n ; i++){
        arr.push_back(i);
    }

    return arr;
}

//generate spanning tree with specific prefer code.
void generate_spanning_tree(vector<int> prefer_code, int n){
    //generate vector with size n.
	vector<int> arr = set_of_vertex(n);

	cout<<"Spanning tree: " <<endl;

	for(int i=0 ; i<prefer_code.size() ; i++){

        for(int j=0 ; j<arr.size() ; j++){

            if(find(prefer_code.begin()+i,prefer_code.end(),arr[j]) == prefer_code.end()){
                cout<<prefer_code[i]<<" "<<arr[j]<<endl;
                arr.erase(arr.begin()+j);
                break;
            }
        }  
    }

	//at last we have two element make edge between them.
	cout<<arr[0]<<" "<<arr[1]<<endl;
}

//generate all permutation with n-2 size and according to that permutation generate spanning tree.
//example: n=4 so permutation are (1,1) , (1,2) , .... , (4,4).
void generate_permutation(vector<int> code, int n){

	//if prefer code size == n-2 then generate spanning tree.
	if(code.size() == n-2){
		cout<<"\nPrefer code: ";
		for(auto it : code)
            cout<<it<<" ";
		cout<<endl;

		generate_spanning_tree(code, n);
		return;
	}

	//recursion
	for(int i=1; i<=n; i++){
		code.push_back(i);
		generate_permutation(code, n);
		code.pop_back();
	}
}

int main(){
	cout<<"enter number of element in set : ";
	int n;
	cin >> n;

	cout<<"we need to generate total "<<pow(n,n-2)<<" spanning tree"<<endl;

	vector<int> code;
	generate_permutation(code, n);
	return 0;
	
}

/*
OUTPUT : 

enter number of element in set : 4
we need to generate total 16 spanning tree

Prefer code: 1 1 
Spanning tree:
1 2
1 3
1 4

Prefer code: 1 2
Spanning tree:
1 3
2 1
2 4

Prefer code: 1 3
Spanning tree:
1 2
3 1
3 4

Prefer code: 1 4
Spanning tree:
1 2
4 1
3 4

Prefer code: 2 1
Spanning tree:
2 3
1 2
1 4

Prefer code: 2 2
Spanning tree:
2 1
2 3
2 4

Prefer code: 2 3
Spanning tree:
2 1
3 2
3 4

Prefer code: 2 4
Spanning tree:
2 1
4 2
3 4

Prefer code: 3 1
Spanning tree:
3 2
1 3
1 4

Prefer code: 3 2
Spanning tree:
3 1
2 3
2 4

Prefer code: 3 3
Spanning tree:
3 1
3 2
3 4

Spanning tree:
4 1
3 2
3 4

Prefer code: 4 4
Spanning tree:
4 1
4 2
3 4

*/
