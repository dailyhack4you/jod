#include <bits/stdc++.h>
using namespace std;

class undirectedGraph{

private:
    int num_of_vertex, edges;
    char name[50];
    int **graph;
    int *degrees;

public:
    int store[100]{0};
    undirectedGraph(const char n[], int V);
    undirectedGraph(const undirectedGraph &obj);
    ~undirectedGraph();

    void addEdge(int src, int dest);
    int get_num_of_vertex();
    bool isSafe(int v, const int *color, int c);
    bool coloring(int m, int *color, int v);
    int *SolveGraph(int m);
};

undirectedGraph::undirectedGraph(const char n[50], int V){
    num_of_vertex = V;
    std::strcpy(name, n);
    edges = 0;
    graph = new int *[num_of_vertex];
    degrees = new int[num_of_vertex]{0};
    for (int i = 0; i < num_of_vertex; i++)
    {
        graph[i] = new int[num_of_vertex]{0};
    }

    using namespace std;
    cout << "\nGraph Created: " << name << endl;
}

undirectedGraph::~undirectedGraph(){
    for (int i = 0; i < num_of_vertex; i++){
        delete[] graph[i];
    }

    delete[] graph;
    delete[] degrees;

    using namespace std;
    cout << "\nMemory released " << name << endl;
}

void undirectedGraph::addEdge(int src, int dest){
    if ((src >= num_of_vertex) || (dest >= num_of_vertex)){
        return;
    }

    if ((graph[src][dest] == 0)){
        ++edges;
        graph[src][dest] = 1;
        graph[dest][src] = 1;
        ++degrees[src];
        ++degrees[dest];
    }
}

int undirectedGraph::get_num_of_vertex(){
    return num_of_vertex;
}

bool undirectedGraph::isSafe(int v, const int *color, int c){
    for (int i = 0; i < num_of_vertex; i++)
        if (graph[v][i] && c == color[i])
            return false;
    return true;
}

bool undirectedGraph::coloring(int m, int *color, int v){
    if (v == num_of_vertex)
        return true;

    for (int c = 1; c <= m; c++){
        if (isSafe(v, color, c)){
            color[v] = c;
            if (coloring(m, color, v + 1) == true)
                return true;

            color[v] = 0;
        }
    }
    return false;
}

int *undirectedGraph::SolveGraph(int m){
    int *color = (int *)calloc(num_of_vertex, sizeof(int));

    if (coloring(m, color, 0) == false){
        return nullptr;
    }
    return color;
}

int main(){
    int num_of_vertex, num_of_edge;

    cout << "Enter Number Of Vertices : ";
    cin >> num_of_vertex;
    cout << "Enter Number Of Edges : ";
    cin >> num_of_edge;

    undirectedGraph G("Kirchoff", num_of_vertex);

    cout<<"Enter all edges : "<<endl;
    for (int i = 0; i < num_of_edge; i++){
        int src,dest;
        cin >> src >> dest;
        G.addEdge(src, dest);
    }

    int m = 1;
    int *solution = nullptr;

    while (true){
        solution = G.SolveGraph(m);
        if (solution != nullptr){
            break;
        }
        ++m;
    }

    cout << "\nChromatic number : " << m << endl;
    for (int i = 0; i < G.get_num_of_vertex(); i++){
        cout << solution[i] << " ";
    }

    vector<vector<int>> ind_set(m + 1, vector<int>());
    for (int i = 0; i < G.get_num_of_vertex(); i++){
        ind_set[solution[i]].push_back(i);
    }
    cout << endl;
    cout<< endl;
    cout << "All Independent Sets : " << endl;
    for (int i = 1; i <= m; i++)
    {
        for (int it : ind_set[i])
        {
            cout << it << " ";
        }
        cout << endl;
    }

    return 0;
}
