#include <bits/stdc++.h>
using namespace std;

//function that check all condition and tell whether given vertex is Ariticulation point or not.
void APUtil(vector<int> graph[], int u, bool visited[],int disc[], int low[], int& time, int parent,bool isAP[]){
    
    int noOfChild = 0;
    visited[u] = true;
    disc[u] = low[u] = ++time;
 
    // loop through which is adj to u.
    for (auto v : graph[u]) {
        if (!visited[v]) {
            noOfChild++;
            APUtil(graph, v, visited, disc, low, time, u, isAP);
 
            // Check if the subtree rooted with v has a connection to one of the ancestors of u
            low[u] = min(low[u], low[v]);
 
            // If u is not root and low value of one of its child is more than discovery value of u.
            if (parent != -1 && low[v] >= disc[u])
                isAP[u] = true;
        }
 
        // Update low value of u for parent function calls.
        else if (v != parent){
             low[u] = min(low[u], disc[v]);
        }       
    }
 
    // If u is root of DFS tree and has two or more noOfChild.
    if (parent == -1 && noOfChild > 1){
        isAP[u] = true;
    }      
}
 
void findArticulationPoint(vector<int> graph[], int V){
    
    //initilize all required variable.
    int disc[V] = { 0 };
    int low[V];
    bool visited[V] = { false };
    bool isAP[V] = { false };
    int time = 0, par = -1;

    for (int u = 0; u < V; u++)
        if (!visited[u])
        APUtil(graph, u, visited, disc, low, time, par, isAP);
 
    int count = 0;
    for(int u=0 ; u<V ; u++)
        if(isAP[u] == false)
            count++;

    if(count == V){
        cout<<"\nNo articulation point..";
    }
    else{
         cout<<"\nArticulation point : ";
         for (int u = 0; u < V; u++)
            if (isAP[u] == true)
                cout << u << " ";
    }
   
}
 
void addEdge(vector<int> graph[], int u, int v)
{
    graph[u].push_back(v);
    graph[v].push_back(u);
}
 
int main()
{
    int V,E;
    cout<<"Enter the number of vertex : ";
    cin>>V;
    cout<<"Enter the number of edges : ";
    cin>>E;

    vector<int> graph1[V];

    cout<<"Enter all edges : "<<endl;
    for(int i=0 ; i<E ; i++){
        int tmp1,tmp2;
        cin>>tmp1>>tmp2;
        addEdge(graph1,tmp1,tmp2);
    }

    findArticulationPoint(graph1,V);
 
    return 0;
}