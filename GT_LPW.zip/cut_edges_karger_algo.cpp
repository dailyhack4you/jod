#include <bits/stdc++.h>
using namespace std;

int find(struct subset subsets[], int i);
void Union(struct subset subsets[], int x, int y);

//edge
struct Edge
{
    int src, dest;
};

//graph with number of vertex and edges
//each edge pair
struct Graph
{
    int v, e;
    Edge *edge;
};

struct subset
{
    int parent;
    int rank;
};

//kerger's therom to find the cut edges in graph.
int kargerMinCut(struct Graph *graph)
{
    int v = graph->v;
    int e = graph->e;
    Edge *edge = graph->edge;

    // Allocate memory for creating V subsets.
    struct subset *subsets = new subset[v];

    // Create V subsets with single elements
    for (int i = 0; i < v; i++)
    {
        subsets[i].parent = i;
        subsets[i].rank = 0;
    }

    int vertices = v;

    //keep doing contracting until we have 2 vertex.
    while (vertices > 2)
    {
        int i = rand() % e;

        int subset1 = find(subsets, edge[i].src);
        int subset2 = find(subsets, edge[i].dest);

        if (subset1 == subset2)
            continue;
        else
        {
            printf("Contracting edge %d-%d\n",
                   edge[i].src, edge[i].dest);
            vertices--;
            Union(subsets, subset1, subset2);
        }
    }

    int cutedges = 0;
    for (int i = 0; i < e; i++)
    {
        int subset1 = find(subsets, edge[i].src);
        int subset2 = find(subsets, edge[i].dest);
        if (subset1 != subset2)
            cutedges++;
    }
    return cutedges;
}

int find(struct subset subsets[], int i)
{
    // find root and make root as parent of i
    if (subsets[i].parent != i)
        subsets[i].parent = find(subsets, subsets[i].parent);

    return subsets[i].parent;
}

void Union(struct subset subsets[], int x, int y)
{
    int xroot = find(subsets, x);
    int yroot = find(subsets, y);

    if (subsets[xroot].rank < subsets[yroot].rank)
        subsets[xroot].parent = yroot;
    else if (subsets[xroot].rank > subsets[yroot].rank)
        subsets[yroot].parent = xroot;
    else
    {
        subsets[yroot].parent = xroot;
        subsets[xroot].rank++;
    }
}

struct Graph *createGraph(int v, int e)
{
    Graph *graph = new Graph;
    graph->v = v;
    graph->e = e;
    graph->edge = new Edge[e];
    return graph;
}

int main()
{
    int v,e;
    cout<<"Enter the Number of Vertices : ";
    cin>>v;
    cout<<"Enter the Number of Edges : ";
    cin>>e;
    struct Graph *graph = createGraph(v, e);

    cout<<"Enter all edges :"<<endl;
    for(int i=0;i<e;i++)
    {
        cin>>graph->edge[i].src>>graph->edge[i].dest;
    }

    srand(time(NULL));

    cout<<endl<<"Number of Cut Edges by karger's therom  : "<<kargerMinCut(graph);

    return 0;
}

