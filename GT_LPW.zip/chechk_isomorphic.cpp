#include<bits/stdc++.h>
using namespace std;

int v1,v2,e1,e2;
//taking two graph with 10 vertex by default.
vector<vector<int>> first_graph(10);
vector<vector<int>> second_graph(10);

//fun that check the degree of vertex same or not.
bool degree_matching(vector< vector<int> >g1,vector< vector<int> > g2){
    //vector used for matching of degree.
    int n=g1.size();
    vector<int> d1(n),d2(n);

    //taking each vertex and check their degree if degree is not zero then to go that index and add 1.
    for(int i=0;i<n;i++){
        if(g1[i].size() != 0)
            d1[g1[i].size()]++;

        if(g2[i].size() != 0)
            d2[g2[i].size()]++;
    }

    //degree vector to show each degree how many vertex have ?
    cout<<"\n";
    for(int i=0 ; i<d1.size() ; i++)
        cout<<d1[i]<<" ";
    cout<<endl;

    for(int i=0 ; i<d2.size() ; i++)
        cout<<d2[i]<<" ";
    cout<<endl;


    //if degree is not matching then not isomorphic.
    for(int i=0;i<g1.size();i++)
        if(d1[i]!=d2[i])
            return false;
    return true;
}

//fun that check three condition :
//1. number of vertex must same.
//2. number of edges must same.
//3. able to match each vertex of one graph to another.
bool check_isomorphic(vector< vector<int> > g1,vector< vector<int> > g2){
    if(v1 != v2 && e1 != e2){
        cout<<"\nnumber of vertices or degree not same."<<endl;
        return false;
    }
    else if(degree_matching(g1,g2) == false){
        cout<<"\nOOPS! Degree matching is not posible."<<endl;
        return false;
    }
    else
        return true;
}

int main()
{
    //int v1, v2, e1, e2;
    int vertex1, vertex2;

    //taking vertex & edges for first graph.
    cout<<"--------------- GRAPH 1 ---------------\n";
    cout << "Vertices & Edges : ";
    cin >> v1 >> e1;


    cout << "Enter all edges : \n";
    for(int i=0; i<e1; i++) {
        cin >> vertex1 >> vertex2;
        first_graph[vertex1].push_back(vertex2);
        first_graph[vertex2].push_back(vertex1);
    }

    //taking vertex & edges for second graph.
    cout<<"--------------- GRAPH 2 ---------------\n";
    cout << "Vertices & Edges: ";
    cin >> v2 >> e2;


    cout << "Enter all edges : \n";
    for(int i=0; i<e2; i++) {
        cin >> vertex1 >> vertex2;
        second_graph[vertex1].push_back(vertex2);
        second_graph[vertex2].push_back(vertex1);
    }

    if(check_isomorphic(first_graph,second_graph))
        cout<<"\nIsomorphic\n";
    else
        cout<<"\nNot Isomorphic\n";

    return 0;
}

/*
Example of isomprphic :-

--------------- GRAPH 1 ---------------
Vertices & Edges : 7 6
Enter all edges :
0 1
1 2
2 3
3 4
3 5
5 6
--------------- GRAPH 2 ---------------
Vertices & Edges: 7 6
Enter all edges :
0 1
1 2
2 3
2 4
4 5
5 6

0 3 3 1 0 0 0 0 0 0
0 3 3 1 0 0 0 0 0 0

Isomorphic

Example of not isomorphic :-

--------------- GRAPH 1 ---------------
Vertices & Edges : 4 4
Enter all edges :
0 1
0 3
1 2
2 3
--------------- GRAPH 2 ---------------
Vertices & Edges: 4 4
Enter all edges :
4 5
5 6
4 6
6 7

0 0 4 0 0 0 0 0 0 0
0 1 2 1 0 0 0 0 0 0

OOPS! Degree matching is not posible.

Not Isomorphic

*/
