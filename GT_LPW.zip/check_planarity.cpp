#include <bits/stdc++.h>
using namespace std;

class undirectedGraph{
public:
    static int count;
    int id;
    int num_of_vertex;
    int num_of_edge;
    vector<set<int>> graph;
    undirectedGraph(int V);
    void addEdge(int u, int v);
    static int getNextID();
    int containsCycle();
    bool isPlanner();
};

int undirectedGraph::count{ 0 };

int undirectedGraph::getNextID(){
    return ++count;
}

undirectedGraph::undirectedGraph(int V){
    id = getNextID();
    num_of_vertex = V;
    num_of_edge = 0;
    for (int i = 0; i < num_of_vertex; i++)
        graph.push_back(set<int>{});
}

void undirectedGraph::addEdge(int u, int v){
    auto it = find(graph[u].begin(), graph[u].end(), v);
    if (it == graph[u].end())
        num_of_edge++;
    graph[u].insert(v);
    graph[v].insert(u);
}

int undirectedGraph::containsCycle(){
    int *visited = new int[num_of_vertex]();

    visited[0] = 1;
    for (int i = 0; i < num_of_vertex; i++)
        for (auto &&j : graph[i])
            if (j > i && visited[j]) return 1;
            else visited[j] = 1;

    delete[] visited;
    return 0;
}

bool undirectedGraph::isPlanner(){

    if (containsCycle()){
        if (num_of_edge <= (3 * num_of_vertex - 6)) return true;
        else return false;
    }
    else{
        if (num_of_edge <= (2 * num_of_vertex - 4)) return true;
        else return false;
    }
}

int main(){
    int num_of_vertex, num_of_edge;
    cout << "Enter the number of vertex : ";
    cin >> num_of_vertex;
    cout << "Enter the number of edge : ";
    cin >> num_of_edge;

    undirectedGraph G(num_of_vertex);

    cout<<"Enter all edges : "<<endl;
    for (int i = 0; i < num_of_edge; i++){
        int u,v;
        cin >> u >> v;
        G.addEdge(u, v);
    }
    
    if(G.isPlanner()) cout<<"Planar"<<endl;
    else cout<<"Not Planar"<<endl;

    return 0;
}