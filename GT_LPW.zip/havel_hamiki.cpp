#include <bits/stdc++.h>
using namespace std;
 
bool havelHakimi(vector<int> &a, int n){
    while (true){
        //sort the sequence in decreasing order.
        sort(a.begin(), a.end(), greater<int>());
 
        //base case
        if (a[0] == 0)
            return true;
 
        //store element and remove it.
        int v = a[0];
        a.erase(a.begin() + 0);
 
        //next v element present or not.
        if (v > a.size())
            return false;
 
        //subtract 1 from next v element.
        for (int i = 0; i < v; i++){
            a[i]--;
 
            //if any element become negative
            //degree sequence is not graphical
            if (a[i] < 0)
                return false;
        }
    }
}
 
int main()
{
    int t;
    cout<<"Enter the number of test cases : ";
    cin>>t;
    
    while(t--){
        vector<int> degree_seq;
        int n;
        cout<<"\nEnter the size of degree sequence : ";
        cin>>n;
        
        cout<<"Enter degree sequence : ";
        for(int i=0 ; i<n ; i++){
            int temp;
            cin>>temp;
            
            degree_seq.push_back(temp);
        }
     
        if(havelHakimi(degree_seq , n))
            cout<<"YES! Simple graph exist.\n";
        else
            cout<<"NO! Simple graph not exist.\n";
 
    }
    
    return 0;
}