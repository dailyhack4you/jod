#include <bits/stdc++.h>
#include <list>
using namespace std;
 
class Graph
{
    int V;   
    list<int> *adj;    
public:

    Graph(int V){ this->V = V; adj = new list<int>[V]; }
    void addEdge(int u, int v);
    void graphColoring();
};
//add edge to graph.
void Graph::addEdge(int u, int v)
{
    adj[u].push_back(v);
    adj[v].push_back(u); 
}
 
//function to color each vertex and find chromatic number.
void Graph::graphColoring()
{
    int result[V];
 
    //first color(color start from 0) to first vertex
    result[0]  = 0;
 
    //assign -1 to remaining vertex which that vertex is not colored.
    for (int u = 1; u < V; u++)
        result[u] = -1;  
 
    //to show available color for that vertex.
    bool available[V];
    for (int cr = 0; cr < V; cr++)
        available[cr] = false;
 
    //Assign colors to remaining V-1 vertices
    for (int u = 1; u < V; u++)
    {
        list<int>::iterator i;

        for (i = adj[u].begin(); i != adj[u].end(); ++i)
            if (result[*i] != -1)
                available[result[*i]] = true;
 
        int cr;
        for (cr = 0; cr < V; cr++)
            if (available[cr] == false)
                break;
 
        //find first available color and assign to it.
        result[u] = cr; 
 
        // Reset value for next iteration.
        for (i = adj[u].begin(); i != adj[u].end(); ++i)
            if (result[*i] != -1)
                available[result[*i]] = false;
    }
  
    cout<<endl;
    cout<<"vertex"<<" | "<<"color"<<endl;
    cout<<"------------------"<<endl;
    for (int u = 0; u < V; u++){
        cout <<"  "<<u <<"    |   "<< result[u] << endl;
    }
        
    int chromaticNumber = 1;
    sort(result,result+V);
    for(int i=1 ; i<V ; i++){
        if(result[i-1] != result[i]){
            chromaticNumber++;
        }
    }

    cout<<endl;
    cout<<"chromatic number : "<<chromaticNumber<<endl;
}
 
int main()
{
    int V,E;
    cout<<"Enter the Number of Vertices : ";
    cin>>V;
    cout<<"Enter the Number of Edges : ";
    cin>>E;
    Graph g(V);

    cout<<"Enter all edges : "<<endl;
    for (int i = 0; i < E; i++)
    {
        int src,dest;
        cin>>src>>dest;
        g.addEdge(src, dest);
    }

    g.graphColoring();
 
    return 0;
}